<?php 
require_once("cn.php"); 

if(isset($_POST["del"])){ 
    if(!(isset($_POST["eliminar"]))){ 
        echo "Seleccione un registro"; 
    }else{ 
        $categoria=$_POST["eliminar"]; 
        foreach($categoria as $idcategoria){ 
            $sql="delete from categoria where idcategoria='$idcategoria'"; 
            $conn->query($sql);     
        } 
    } 
} 
?> 
<script> 
function convertir(){ 
    var texto=document.getElementById("pelicula").value; 
      
    if(window.XMLHttpRequest){ 
         objetoAjax=new XMLHttpRequest(); 
    } 
    objetoAjax.onreadystatechange=function(){ 
         if(objetoAjax.readyState==4 && objetoAjax.status==200){ 
             document.getElementById("respuesta").innerHTML=objetoAjax.responseText; 
         } 
    } 

    objetoAjax.open("GET","ajax.php?pelicula="+texto); 
    objetoAjax.send(); 
} 
</script>     
     
<div align="center">     

<div>Filtrar Peliculas </div> 
<form method="post"> 
<label for="nombre" class="first-name"><b>Nombre Pelicula: </b></label><br> 
             
<label for="nombre" class="first-name" ><b>Pelicula: </b></label> 
<input type="text" id="pelicula" onkeyup="convertir()" class="inputArea" required><br> 

</form> 
         
<div id=respuesta></div>     
</div> 
 <?php 
 show_source("consultapelis.php"); 
 ?> 