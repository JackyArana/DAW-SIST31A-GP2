<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="" method="POST">
	<fieldset>
	<legend style="color:black; font-size:30px; font-family:Showcard Gothic;">&nbsp;&nbsp;&nbsp;&nbsp;MARCAS</legend>
	<br>
	<table border="0px"  style="width:100%; background-color:whites; height:auto; color:black; font-size:13px; font-family:Arial, sans-serif; float:left;" >
								<!-- Aqui son las primeras imagenes-->
								<td>

										<table style="background:transparent;margin-right:opx;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR1" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC1" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>


								


								<!-- Aqui son las Segundas imagenes-->
								<td>
									
										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										
										</table> 
								</center>
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR2" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC2" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
										</tr>
									</table>
										
									</td>

								


								<!-- Aqui son las terceras imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR3" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC3" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR4" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC4" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									</table>

									<!--aqui termina prueba-->
									<br>

									<!--PRUEBA de OTRA Tabla-->
<table border="0px"  style="width:100%; background-color:whites; height:auto; color:black; font-size:13px; font-family:Arial, sans-serif; float:left;" >
								<!-- Aqui son las primeras imagenes-->
								<td>

										<table style="background:transparent;margin-right:opx;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src=img/"navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR5" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC5" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>


								


								<!-- Aqui son las Segundas imagenes-->
								<td>
									
										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										
										</table> 
								</center>
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR6" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC6" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
										</tr>
									</table>
										
									</td>

								


								<!-- Aqui son las terceras imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR7" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC7" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="MR8" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC8" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									</table>
									<!--End-->						
								

</fieldset>
<br>
<br>
<fieldset>
<legend style="color:black; font-size:30px; font-family:Showcard Gothic;">&nbsp;&nbsp;&nbsp;&nbsp;PRECIO</legend>		
				<br>
<table border="0px" style=" background-color:white; width:100%; height:auto; color:black; font-size:13px; font-family:Arial, sans-serif; float:left; " >
<!--estas son las primeras imagenes-->
	<td>

			<table>
				
				<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
				<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
				</td>

			</table>	
		
		
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR1" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC1" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
		</td>


	

	<!-- Aqui son las segundas imagenes-->	
	<td>

			<table>
				
				<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
				<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
				</td>

			</table>	

								<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR2" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC2" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
	</td>	

	

	<!-- Aqui son las terceras imagenes-->	
	<td>

			<table>
				
				<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
				<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
					<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
				</td>

			</table>	

	
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR3" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC3" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">				</table>
										
	
	<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR4" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC4" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">	</table>
										
									</td>

									<!--aqui termina prueba-->
		</table>
			<br>
									
									<!--PRUEBA de OTRA Tabla-->
<table border="0px"  style="width:100%; background-color:whites; height:auto; color:black; font-size:13px; font-family:Arial, sans-serif; float:left;" >
								<!-- Aqui son las primeras imagenes-->
								<td>

										<table style="background:transparent;margin-right:opx;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR5" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC5" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>


								


								<!-- Aqui son las Segundas imagenes-->
								<td>
									
										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										
										</table> 
								</center>
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR6" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC6" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
										</tr>
									</table>
										
									</td>

								


								<!-- Aqui son las terceras imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR7" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC7" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="PR8" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="PC8" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									</table>
									<!--End-->
						
</fieldset>
<br>
<br>
											<fieldset>
											<legend style="color:black; font-size:30px; font-family:Showcard Gothic;">&nbsp;&nbsp;&nbsp;&nbsp;AÑO</legend>
																<br>					
											<table border="0px" style="background-color:white; width:100%; height:auto; color:black ; font-size:13px; font-family:Arial, sans-serif; float:left; " >
											<!--estas son las primeras imagenes-->
												<td>

														<table>
															
															<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
															<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
															</td>

														</table>	
													
																				<table style="background:transparent;">
																				<td>Descripcion: Motor RTH200, 5 velocidades 4x4
																					<tr>
																				<td>Marca: YAMAHA. 
																					<tr>
																				<td>Precio: $2,000
																					<tr>
																				<td>Año:2000.
																				<input type="image" name="AR1" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC1" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">	</table>
																				
													</td>


												<td>

												<!-- Aqui son las segundas imagenes-->	
												<td><center>

														<table>
															
															<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
															<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
															</td>

														</table>	

												</center>
												<center>
																				<table style="background:transparent;">
																				<td>Descripcion: Motor RTH200, 5 velocidades 4x4
																					<tr>
																				<td>Marca: YAMAHA. 
																					<tr>
																				<td>Precio: $2,000
																					<tr>
																				<td>Año:2000.
																				<input type="image" name="AR2" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC2" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">		</table>
																					</center>
												</td>	

												<td>

												<!-- Aqui son las terceras imagenes-->	
												<td><center>

														<table>
															
															<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
															<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
																<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
															</td>

														</table>	

												</center>
													<center>
																				<table style="background:transparent;">
																				<td>Descripcion: Motor RTH200, 5 velocidades 4x4
																					<tr>
																				<td>Marca: YAMAHA. 
																					<tr>
																				<td>Precio: $2,000
																					<tr>
																				<td>Año:2000.
																				<input type="image" name="AR3" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC3" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">		</table>
																		<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src=img/"navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="AR4" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC4" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">	</table>
										
									</td>

									<!--aqui termina prueba-->
	
													</table>
														<br>
									
									<!--PRUEBA de OTRA Tabla-->
<table border="0px"  style="width:100%; background-color:whites; height:auto; color:black; font-size:13px; font-family:Arial, sans-serif; float:left;" >
								<!-- Aqui son las primeras imagenes-->
								<td>

										<table style="background:transparent;margin-right:opx;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="AR5" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC5" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>


								


								<!-- Aqui son las Segundas imagenes-->
								<td>
									
										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										
										</table> 
								</center>
										
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="AR6" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC6" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
										</tr>
									</table>
										
									</td>

								


								<!-- Aqui son las terceras imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="AR7" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC7" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									<!--Probando nueva fila-->
									</td>

								


								<!-- Aqui son las cuartas imagenes-->
								<td>

										<table style="background:transparent;">
											
											<td rowspan="2"><img src="img/navidad.jpg" style="width:140px; height:200px; margin-top:0px;"></tr>
											<td> <img src="img/navidad.jpg" style="width:130px; height:57px; margin:;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
												<img src="img/navidad.jpg" style="width:130px; height:57px;"><br>
											</td>
										</table>

									
									<table style="background:transparent;">
									<td>Descripcion: Motor RTH200, 5 velocidades 4x4
										<tr>
									<td>Marca: YAMAHA. 
										<tr>
									<td>Precio: $2,000
										<tr>
									<td>Año:2000.
									<input type="image" name="AR8" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="AC8" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
									</table>
										
									</td>

									</table>
									<!--End-->
											</fieldset>



										<br>
										<br>
										<br>

</form>


		
</body>
</html>