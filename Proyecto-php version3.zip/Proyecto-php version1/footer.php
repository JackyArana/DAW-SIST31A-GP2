<!DOCTYPE html>
<html>
<head>
	<title>footer</title>
	<style type="text/css">
		.pie{
				width: 100%;
				height: 40px;
				background:linear-gradient(transparent,red);
				font-family: Elephant;
				font-size: 35px;
				color: white;
		
			}
	</style>
</head>
<body>

<footer class="pie"> <center>Escuela especializada ITCA-FEPADE</center></footer>
</body>
</html>
