<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema De Venta Y Reservacion de Autos</title>
<meta name="viewport" content="initial-scale=1">
<link rel="stylesheet" href="estilos.css">
</head>
<body>
    <form action="resultado.php" method="post">
    <h2>Reservar Auto</h2>
    <label for="TipoA">Seleccione el Auto que desea reservar:</label>   
    <select name="tipo_equipo">
<option>[-Seleccione una opcion-]</option>

</select>
    <label for="fechaR">Fecha de  Reservacion:</label> 
    <input type="date" name="Reservacion" class="user"   title="Seleccione la fecha de inicio de reservacion" required=""/>
    <label for="fechaD">Fecha de Devolucion:</label> 
    <input type="date" name="Devolucion" class="user"   title="Seleccione la fecha de devolucioncion" required=""/>
    
    <input type="submit" name="submit" value="Reservar" id="boton" />
    </form>
</body>
</html>