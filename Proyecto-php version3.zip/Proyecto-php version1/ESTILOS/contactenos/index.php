<!DOCTYPE html>
<html lang"es">
   <head>
       <title>Formulario de Vehiculos</title>
       <meta charset="UTF-8">
       <link rel="stylesheet" href="estilos.css">
   </head>
   <body>
      <form action="enviar.php" method="post">
          <h2>FORMULARIO DE VEHICULO</h2>
          <select name "select1" id "sele" required>
            <option value="1">NUMERO DE SERIE</option>
            <option value="1">N</option>
            <option value="1">N</option>
          </select>
          <BR>
          <BR>
          <BR>
          <select name "select2" id "sele2" required>
            <option value="1">MARCA</option>
            <option value="1">N</option>
            <option value="1">N</option>
          </select> 
           <BR>
          <BR>
          <BR>
          <input type="text" name="modelo" placeholder="modelo" required>
          <input type="text" name="anio_vehiculo" placeholder="año de vehiculo" required>
          <input type="text" name="matricula" placeholder="matricula" required>
           <input type="text" name="kilometraje" placeholder="kilometraje" required>
            <input type="text" name="transmision" placeholder="transmision" required>
             <input type="text" name="cilindros" placeholder="cilindros" required>
              <input type="text" name="caballos_fuerza" placeholder="caballos de fuerza" required>
               <input type="text" name="carateristica" placeholder="carateristica" required>
          <input type="submit" value="ENVIAR" id="boton">
      </form>
   </body>
</html>