<?php
   $destino= "contacto@sateli3.com";
   $sele1 = $_POST["sele1"];
   $marca = $_POST["marca"];
   $modelo = $_POST["modelo"];
   $anio_vehiculo = $_POST["anio_vehiculo"];
   $matricula = $_POST["matricula"]
   $kilometraje = $_POST["kilometraje"];
    $transmision = $_POST["transmision"];
     $cilindros = $_POST["cilindros"];
      $caballos_fuerza = $_POST["caballos_fuerza"];
       $carateristica = $_POST["carateristica"];
   $contenido = "num_serie: " . $sele1 . "\nmarca: " . $marca . "\nmodelo: " . $modelo . "\nanio_vehiculo: " . $anio_vehiculo . "\nmatricula: " . $matricula . "\nkilometraje: " . $kilometraje . "\ntransmision: " . $transmision . "\ncilindros: " . $cilindros . "\ncaballos de fuerza: " . $caballos_fuerza . "\ncaracteristicas: " . $carateristica;
   mail($destino,"Contacto", $contenido);
   header("location:recibido.html");
?>