<?php
   $destino= "contacto@sateli3.com";
   $sele1 = $_POST["sele1  "];
   $foto = $_POST["foto"];
   $esportada = $_POST["esportada   "];
   
   $contenido = "sele1: " . $sele1  . "\nfoto: " . $foto . "\nesportada: " . $esportada;
   mail($destino,"Contacto", $contenido);
   header("location:recibido.html");
?>