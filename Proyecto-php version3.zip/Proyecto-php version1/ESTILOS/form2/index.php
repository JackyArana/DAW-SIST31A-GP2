<!DOCTYPE html>
<html lang"es">
   <head>
       <title>Formulario de Contacto</title>
       <meta charset="UTF-8">
       <link rel="stylesheet" href="estilos.css">
   </head>
   <body>
      <form action="enviar.php" method="post">
          <h2>CONTACTENOS</h2>
          <select name "select1" id "sele" required>
            <option value="1">NUMERO DE SERIE</option>
            <option value="1">N</option>
            <option value="1">N</option>
          </select>
          <BR>
          <BR>
          <BR>
          
          <input type="file" name="foto" placeholder="foto" required>
          <input type="file" name="esportada	" placeholder="esportada	" required>
         
          <input type="submit" value="ENVIAR" id="boton">
      </form>
   </body>
</html>