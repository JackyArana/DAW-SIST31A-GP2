<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<link rel="stylesheet" type="text/css" href="catest.css">
<form action="" method="POST">

<center>s
<table border="0px" style="font-size:30px;">
<td style="height:30px;">Numero de serie</td>
<td><input type="text"></td>
	<tr>
<td style="height:30px;">Ingrese el id</td>
<td><select>

	</select>
	<tr>
<td style="height:30px;">Modelo</td>
<td><input type="text"></td>
	<tr>
<td style="height:30px;">año del vehiculo</td>
<td><input type="number" min="1980" max="2020" value="1980"></td>
	<tr>
<td style="height:30px;">Matricula</td>
<td><input type="text"></td>
	<tr>
<td style="height:30px;">Kilometraje</td>
<td><input type="number"></td>
	<tr>
<td style="height:30px;">transmision</td>
<td><select>
	<option>Mecanico</option>
	<option>Automatico</option>
	</select>
</td>
	<tr>
<td style="height:30px;">Cilindros</td>
<td><input type="number" min="1" max="10" value="3"></td>
	<tr>
<td style="height:30px;">Caballos de Fuerzas</td>
<td><input type="number" min="1" Max="10000" value="100"></td>
	<tr>
<td style="height:30px;">Caracteristicas</td>
<td><textarea rows="10" cols="20" wrap="soft"></textarea></td>
	<tr>
<td style="height:30px;">Precio de Compra</td>
<td><input type="number" step="0.001"></td>
	<tr>
<td style="height:30px;">Precio de Venta</td>
<td><input type="number" step="0.001"></td>
	<tr>
<td style="height:30px;">Estado</td>
<td><select>
	<option>Disponible</option>
	<option>Vendido</option>
	<option>En proceso</option>	
	<option>En Venta</option>	
	<option>Reservado</option>
	</select></td>
	<tr>
</table></center>

<!--

	<br>
	<div class="separ">	
		<br>						
		<div class="slider">
			<ul>
				<li>
  <img src="carro1/car1.jpg" alt="">
 </li>
				<li>
  <img src="carro1/car2.jpg"   alt="">
</li>
				<li>
  <img src="carro1/car3.jpg"    alt="">
</li>
				<li>
  <img src="carro1/car4.jpg"   alt="">
</li>
				<li>
  <img src="carro1/car5.jpg"   alt="">
</li>
				<li>
  <img src="carro1/car6.jpg"   alt="">
</li>
				<li>
  <img src="carro1/car7.jpg"   alt="">
</li>
			</ul>
		</div>
		</div>
		
		<div class="descripcion">
				<br>
			<p>Descripcion:</p><p class="L">URGE VENDER PICK UP ISUZU JMC, AÑO 2008, DIESEL, 4X4, CABINA SENCILLA , CAMA DE TRABAJO, CON ...<a href="index.php">Leer Mas..</p>
				<br>
	
		<style>
		.slider {
	width: 100%;
	height:auto;
	overflow: hidden;
}

.slider ul {

	display: flex;
	padding: 6px;
	width: 690%;
	
	animation: cambio 20s infinite alternate linear;
}

.slider li {
	width: 100%;
	list-style: none;
}

.slider img {
	width: 105%;
}

@keyframes cambio {
	0% {margin-left: 0;}
	20% {margin-left: 0;}
	
	25% {margin-left: -100%;}
	45% {margin-left: -100%;}
	
	50% {margin-left: -200%;}
	70% {margin-left: -200%;}
	
	75% {margin-left: -300%;}
	100% {margin-left: -300%;}
}
</style>	
									<input type="image" name="MR1" img src="img/reservar.png" style=" float:right; width:70px; height:30px; color:black; font-size:18px; font-family:Britannic Bold; border-style: none; margin-top:6px;">
									<input type="image" name="MC1" img src="img/compra.jpg" style="float:right;  width:40px; height:40px; background-color:black; color:white; font-size:18px; font-family:Britannic Bold; border-style: none;">
	</div>
										
	


-->			
</form>		
</body>
</html>