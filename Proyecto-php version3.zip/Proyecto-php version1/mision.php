
<html id="uno">
<head>


	<style type="text/css">

#uno{
	
}

	.seccion1{
		line-height: 30px;
		background:transparent;
		box-shadow: 4px 1px 1px white;
		font-family: times, serif;
		font-size: 25px;
		float: left;
		width: 47%;
		height:330px;
		padding: 8px;
		text-shadow: 5px 5px 5px #999;
		
	}


	.seccion2{
		background: transparent;
		box-shadow: 1px 1px 1px white;
		line-height: 30px;
		font-family: times, serif;
		font-size: 25px;
		float: right;
		width: 50.5%;
		height: 330px;
		padding: 8px;
		text-shadow: 5px 5px 5px #999;
		
	}


		.seccion3{
		background: transparent;
		line-height: 30px;
		font-family: times, serif;
		font-size: 25px;
		width: 40%;
		padding-top: 350px;
		margin-left: 550px;
		text-shadow: 4px 4px 4px #999;
	}

	h1{
		font-family: arial black;
		font-size: 35px;
       text-shadow: 5px 5px 5px GRAY;

	}

	
	.pie{
		width: 100%;
		height: 40px;
		background:linear-gradient(transparent,red);
		font-family: Elephant;
		font-size: 35px;
		
	}



	</style>

	
</head>

<body style="background-image: url('img/immision.png');
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size:cover;
	background-size: cover;">
<div>	

<section class="seccion1">
	<h1><center>MISIÓN</center></h1>
	<br>
	<br>
	<P>Comercializar vehículos y prestar servicio a un amplio segmento del mercado automotriz, a través del compromiso de un equipo capacitado para satisfacer todos los requerimientos de nuestros clientes en cada una de las aéreas que conformamos, practicando nuestros valores y teniendo como objetivo la excelencia.</P>
	<br>
</section>
	


<section class="seccion2">
	<h1><center>VISIÓN</center></h1>
	<br>
	<br>
	<P>Ser una empresa reconocida por su calidad de servicio, seriedad y calidez en el trato a las personas.
Estando siempre dispuestos a dar más por usted, es por eso que ponemos a su disposición todos los recursos para una total satisfacción y que reciba la mejor orientación profesional.
</P>
</section>
<br>
<section class="seccion3">
	<h1>VALORES</h1>
	<br>
	<br>
	<p>• Calidad</h2>
	<p>• Transparencia</h2>
	<p>• Trabajo en equipo</h2>
	<p>• Competitividad</h2>
	<p>• Respeto</h2>
	
</section>

	

<br>
<br>
<br>
<br>
<hr size="2px" color="white">
<br>

</div>
</body>





</html>