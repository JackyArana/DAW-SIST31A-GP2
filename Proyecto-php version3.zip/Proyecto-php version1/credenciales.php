<?php
define('SERVIDOR', 'localhost');
define('CONTRA', '');
define('USUARIO', 'root');
define('BASEDATOS', 'sistema_vehiculos');

?>